import axios from 'axios';
import { getServerQuery } from '../helpers/sampQuery';

export const ServerService = {
  async online(adress: string) {
    return await axios
      .get<{ core: ServerResponseType }>('https://api.open.mp/server/' + adress)
      .then(res => res.data.core.pc);
  },

  async getOnline(address: string) {
    const separator = address.lastIndexOf(':');
    const host = separator > -1 ? address.slice(0, separator) : address;
    const port = separator > -1 ? Number(address.slice(separator + 1)) : 7777;
    return getServerQuery({ host, port, timeout: 5000 }).then(res => res);
  },
};

export type ServerType = {
  id: number;
  address: string;
  name?: string;
  icon?: string;
  online?: number;
  slot?: number;
  bonus?: boolean;
};

export type ServerResponseType = {
  ip: string;
  hn: string;
  pc: number;
  pm: number;
  gm: string;
  la: string;
  pa: boolean;
  vn: string;
};
