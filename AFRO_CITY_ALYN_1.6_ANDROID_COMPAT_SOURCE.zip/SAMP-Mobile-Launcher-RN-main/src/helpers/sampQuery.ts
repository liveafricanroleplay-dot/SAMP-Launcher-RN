import { Buffer } from 'buffer';
import dgram from 'react-native-udp';

type QueryType = {
  host: string;
  port?: number;
  timeout?: number;
  opcode?: 'i' | 'r' | 'd';
};

export type QueryTypeResponse = {
  passworded: string;
  players: number;
  maxplayers: number;
  hostname: string;
  gamemode: string;
  mapname: string;
};

export const getServerQuery = async (
  options: QueryType,
): Promise<QueryTypeResponse> => {
  const { host, port = 7777, opcode = 'i', timeout = 1000 } = options;
  const octets = host.split('.').map(part => Number(part));
  if (
    octets.length !== 4 ||
    octets.some(part => !Number.isInteger(part) || part < 0 || part > 255) ||
    !Number.isInteger(port) || port < 1 || port > 65535
  ) {
    throw new Error('Invalid SA-MP server address or port');
  }

  return new Promise((resolve, reject) => {
    const socket = dgram.createSocket({ type: 'udp4' });
    const packet = Buffer.alloc(11);
    packet.write('SAMP', 0, 'ascii');
    packet[4] = octets[0];
    packet[5] = octets[1];
    packet[6] = octets[2];
    packet[7] = octets[3];
    packet[8] = port & 0xff;
    packet[9] = (port >> 8) & 0xff;
    packet[10] = opcode.charCodeAt(0);

    let settled = false;
    const finish = (error?: Error, result?: QueryTypeResponse) => {
      if (settled) return;
      settled = true;
      clearTimeout(controller);
      try { socket.close(); } catch (_) {}
      if (error) reject(error);
      else if (result) resolve(result);
      else reject(new Error('Empty SA-MP server response'));
    };
    const controller = setTimeout(() => finish(new Error('SA-MP server query timed out')), timeout);

    socket.on('error', (error: Error) => finish(error));
    socket.on('message', (response: any) => {
      try {
        if (response.length < 11) throw new Error('Invalid SA-MP response header');
        const payload = response.slice(11);
        if (opcode !== 'i' || payload.length < 11) throw new Error('Invalid SA-MP information response');
        let offset = 0;
        const passworded = payload.readUInt8(offset) ? '1' : '0';
        offset += 1;
        const players = payload.readUInt16LE(offset); offset += 2;
        const maxplayers = payload.readUInt16LE(offset); offset += 2;
        const readString = () => {
          if (offset + 4 > payload.length) throw new Error('Incomplete SA-MP response');
          const length = payload.readUInt32LE(offset); offset += 4;
          if (length > payload.length - offset) throw new Error('Invalid SA-MP string length');
          const value = decode(payload.slice(offset, offset + length));
          offset += length;
          return value;
        };
        finish(undefined, { passworded, players, maxplayers, hostname: readString(), gamemode: readString(), mapname: readString() });
      } catch (error: any) {
        finish(error instanceof Error ? error : new Error('Invalid SA-MP response'));
      }
    });

    try {
      socket.bind(() => socket.send(packet, 0, packet.length, port, host, (error: Error | null) => {
        if (error) finish(error);
      }));
    } catch (error: any) {
      finish(error instanceof Error ? error : new Error('Unable to send SA-MP query'));
    }
  });
};

const decode = (buffer: any) => {
  let charset = '';
  for (let i = 0; i < 128; i++) charset += String.fromCharCode(i);
  charset += '€�‚ƒ„…†‡�‰�‹�����‘’“”•–—�™�›���� ΅Ά£¤¥¦§¨©�«¬­®―°±²³΄µ¶·ΈΉΊ»Ό½ΎΏΐΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡ�ΣΤΥΧΨΩΪΫάέήίΰαβγδεζηθικλμνξοπρςστυϊϋόύώ�';
  const charsetBuffer = Buffer.from(charset, 'ucs2');
  const decodeBuffer = Buffer.alloc(buffer.length * 2);
  for (let i = 0; i < buffer.length; i++) {
    decodeBuffer[i * 2] = charsetBuffer[buffer[i] * 2];
    decodeBuffer[i * 2 + 1] = charsetBuffer[buffer[i] * 2 + 1];
  }
  return decodeBuffer.toString('ucs2');
};
