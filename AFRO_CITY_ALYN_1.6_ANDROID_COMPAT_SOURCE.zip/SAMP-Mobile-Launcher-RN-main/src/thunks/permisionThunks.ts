import { PermissionsAndroid, Platform } from 'react-native';
import { setPermisions } from '../actions/permisionActions';
import { AppThunk } from '../store/store';

export const fetchPermisions = (): AppThunk => async dispatch => {
  try {
    // The launcher stores files in its own app-specific external directory.
    // Android 10+ does not require broad storage permission for that location.
    let filesRead: 'granted' | 'denied' | 'never_ask_again' = 'granted';
    let filesWrite: 'granted' | 'denied' | 'never_ask_again' = 'granted';

    if (Number(Platform.Version) <= 28) {
      const storage = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
      ]);
      filesWrite = storage[PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE];
      filesRead = storage[PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE];
    }

    const microphone = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );
    const permissions = { filesWrite, filesRead, microphone };
    dispatch(setPermisions(permissions));
    return permissions;
  } catch (err) {
    const denied = {
      filesWrite: 'denied' as const,
      filesRead: 'denied' as const,
      microphone: 'denied' as const,
    };
    dispatch(setPermisions(denied));
    return denied;
  }
};
