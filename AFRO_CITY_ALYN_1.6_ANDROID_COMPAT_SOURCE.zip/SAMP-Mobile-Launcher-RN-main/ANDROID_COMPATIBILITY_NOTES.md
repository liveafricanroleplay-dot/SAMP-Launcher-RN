# ALYN 1.6 Android compatibility patch notes

## What was changed safely
- Preserved the five original 32-bit ARM SA-MP/GTA native engine libraries byte-for-byte.
- Removed a malformed Android permission entry.
- Limited legacy external-storage permissions to Android 9 and older. On Android 10+, launcher/game files use the app-specific external files directory and do not request broad storage access.
- Kept microphone permission handling for in-game voice features.
- Corrected SA-MP UDP query packet IP-byte construction and string-length parsing.
- Ensured server monitoring passes the configured port instead of always querying port 7777.
- Replaced Touch RP branding and unrelated Touch RP service URLs with AFRO CITY RP identity and the supplied Discord invite.

## Important limitations - not a completed Android 15/16 port
- The included game engine is prebuilt for `armeabi-v7a` only. There is no `arm64-v8a` game engine in the supplied archive, so arm64 support must not be enabled for the game engine.
- The supplied prebuilt native libraries are not rebuilt for 16 KB ELF page alignment. Their source code was not supplied. This means compatibility with 16 KB page-size devices cannot be guaranteed.
- The React Native / Android Gradle toolchain remains the original older version. It was deliberately not upgraded blindly because a major toolchain change can break the native game activity and custom native modules.
- The launcher distribution endpoint and CDN are intentionally blank because no AFRO CITY RP distribution JSON or game-file hosting URL was supplied. The launcher cannot download AFRO CITY RP game resources until these are hosted and configured.
- No APK was built or device-tested in this environment: Android SDK and project node_modules are not present. This archive is a source patch, not an installable APK.

## Required before release
1. Host a valid distribution JSON matching `DistributionResponse` in `src/services/distribution.service.ts`.
2. Host the launcher/game cache files and configure the `cdnLauncher` and `cdnCache` values in that JSON.
3. Set `URL_DISTRIBUTION` in `.env` to the real HTTPS distribution JSON URL.
4. Build with a compatible JDK/Android SDK and test the launcher on Android 14, Android 15, and Android 16 devices/emulators where available.
5. Test the game engine separately on a 16 KB page-size device. A true 16 KB fix requires replacement native libraries built from the engine source or an officially compatible engine build.
