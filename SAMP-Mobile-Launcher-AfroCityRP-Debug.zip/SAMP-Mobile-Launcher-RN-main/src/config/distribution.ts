import { APP_VERSION } from '@env';
import { CacheType } from '../actions/loaderActions';
import { DistributionResponse } from '../services/distribution.service';

// ---------------------------------------------------------------------------
// Afro City RP launcher configuration (local, no remote distribution.json).
// Edit the values below to change the server, the game files link or the news.
// ---------------------------------------------------------------------------

// The ONE game files archive (hosted on GitHub Releases).
export const GAME_ZIP_URL =
  'https://github.com/liveafricanroleplay-dot/gamefiles/releases/download/v1/gtasa.2.10.cache.zip';
export const GAME_ZIP_NAME = 'gtasa.2.10.cache.zip';

// Approximate archive size (about 683 MB). Only used for the progress bar and
// the free space check. The real size is read from the download itself.
export const GAME_ZIP_BYTES = 716177408;

// Bump this value to force every player to download the game files again.
export const GAME_FILES_VERSION = 'v1';

export const SERVER_ADDRESS = '142.132.203.47:14585';

export const gameCache: CacheType[] = [
  {
    id: 1,
    name: GAME_ZIP_NAME,
    path: '',
    bytes: [GAME_ZIP_BYTES],
    gpu: '',
  },
];

export const distributionConfig: DistributionResponse & { cache: CacheType[] } =
  {
    cdnLauncher: '',
    cdnCache: '',
    cacheMode: [],
    rss: '',
    versionHash: GAME_FILES_VERSION,
    packageName: 'com.touch.mobile.dark',
    projectName: 'Afro City RP',
    servers: [
      {
        id: 1,
        show: true,
        version: '1.0',
        icon: '',
        events: [],
        slot: 100,
        bonus: false,
        name: 'Afro City RP',
        description: 'Roleplay Server',
        address: SERVER_ADDRESS,
        sampVersion: '0.3.7',
      },
    ],
    // Same version as the installed app, so no launcher update is requested.
    launcher: {
      appVersion: APP_VERSION,
      name: '',
      hash: '',
      bytes: 0,
      size: '',
    },
    filesContinue: ['settings.ini', 'gta_sa.set', 'svconfig.ini'],
    cache: gameCache,
  };
