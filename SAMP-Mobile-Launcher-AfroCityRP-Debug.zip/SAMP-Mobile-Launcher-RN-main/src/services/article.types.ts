export type ArticleType = {
  title: string;
  image: string;
  slug: string;
  description: string;
  created_at: string;
};
