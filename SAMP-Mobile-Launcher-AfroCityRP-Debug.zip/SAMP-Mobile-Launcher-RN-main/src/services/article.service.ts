import { ArticleType } from './article.types';

export type { ArticleType };

const articles: ArticleType[] = [
  {
    title: 'Welcome to Afro City RP',
    image: '',
    slug: '',
    description: 'Roleplay server',
    created_at: 'Tap to join our Discord',
  },
  {
    title: 'Create your character and start your story',
    image: '',
    slug: '',
    description: 'Roleplay server',
    created_at: 'Tap to join our Discord',
  },
];

export const ArticleService = {
  async get() {
    return articles;
  },
};
