import { setAlertNeedSpace } from '../actions/alertActions';
import { formatSizeUnits } from '../helpers';
import { selectBytes, selectFreeSpace } from '../selectors/loaderSelectors';
import { useAppDispatch } from './useAppDispatch';
import { useAppSelector } from './useAppSelector';

export const useSpaceDownlload = (): {
  fetchSpace: () => boolean;
} => {
  const dispatch = useAppDispatch();
  const loader = useAppSelector(selectBytes);
  const freeSpace = useAppSelector(selectFreeSpace);

  const fetchSpace = () => {
    // The zip and the extracted files exist at the same time, so ~2x is needed.
    const need =
      (loader.distributionCacheBytes - loader.downloadsCacheBytes) * 2;
    if (freeSpace < need) {
      dispatch(
        setAlertNeedSpace(true, {
          needSpace: +formatSizeUnits(need),
          currentSpace: +formatSizeUnits(freeSpace),
        }),
      );

      return false;
    }

    return true;
  };

  return { fetchSpace };
};
