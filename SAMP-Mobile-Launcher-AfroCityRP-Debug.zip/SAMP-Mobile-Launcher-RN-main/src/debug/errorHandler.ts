import { Alert } from 'react-native';

// Shows startup errors on screen instead of silently closing the app.
// Remove this import from index.js once the app starts correctly.
const g: any = global;
if (g.ErrorUtils && g.ErrorUtils.setGlobalHandler) {
  const defaultHandler = g.ErrorUtils.getGlobalHandler?.();
  g.ErrorUtils.setGlobalHandler((error: any, isFatal?: boolean) => {
    const text = String((error && (error.stack || error.message)) || error);
    try {
      require('react-native-bootsplash').default.hide();
    } catch (e) {}
    try {
      Alert.alert(
        isFatal ? 'Afro City RP crashed' : 'Afro City RP error',
        text.slice(0, 1500),
      );
    } catch (e) {
      defaultHandler && defaultHandler(error, isFatal);
    }
  });
}
