import React from 'react';
import { ScrollView, Text } from 'react-native';

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  { error: any }
> {
  state = { error: null as any };

  static getDerivedStateFromError(error: any) {
    return { error };
  }

  componentDidCatch() {
    try {
      require('react-native-bootsplash').default.hide();
    } catch (e) {}
  }

  render() {
    if (this.state.error) {
      const e = this.state.error;
      return (
        <ScrollView
          style={{ flex: 1, backgroundColor: '#212231' }}
          contentContainerStyle={{ padding: 20, paddingTop: 60 }}>
          <Text style={{ color: '#fff', fontSize: 18, marginBottom: 10 }}>
            Afro City RP error (send a screenshot of this)
          </Text>
          <Text style={{ color: '#ff9999' }}>
            {String((e && (e.stack || e.message)) || e)}
          </Text>
        </ScrollView>
      );
    }
    return this.props.children;
  }
}
