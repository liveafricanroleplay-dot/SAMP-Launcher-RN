import AsyncStorage from '@react-native-async-storage/async-storage';
import { StackActions } from '@react-navigation/native';
import RNFS from 'react-native-fs';
import { subscribe, unzip } from 'react-native-zip-archive';
import {
  CacheType,
  setCacheReject,
  setCompare,
  setDownloadLoader,
  setSuccessDownload,
} from '../actions/loaderActions';
import {
  GAME_FILES_VERSION,
  GAME_ZIP_BYTES,
  GAME_ZIP_NAME,
  GAME_ZIP_URL,
} from '../config/distribution';
import { FilePath } from '../features/fileManager';
import { navigationRef } from '../routers/RootNavigation';
import { AppThunk } from '../store/store';
import {
  createPushNotificationLoader,
  onUploadTaskEventLoader,
} from './notificationThunks';

// Folders that normally sit at the top of the GTA SA / SA-MP game directory.
// Used to detect a zip that has one extra wrapper folder around everything.
const KNOWN_GAME_ITEMS = [
  'texdb',
  'data',
  'SAMP',
  'audio',
  'models',
  'anim',
  'text',
  'gta_sa.set',
  'gtasatelem.set',
];

// A small marker file proves the game files were fully extracted.
const markerPath = () =>
  `${FilePath.getPathDirCache()}/.afro_gamefiles_${GAME_FILES_VERSION}`;

const isGameInstalled = async () => {
  try {
    return await RNFS.exists(markerPath());
  } catch (e) {
    return false;
  }
};

// Moves everything from srcDir into destDir (merging folders, keeping the
// player's own settings files).
const moveInto = async (
  srcDir: string,
  destDir: string,
  keepFiles: string[],
) => {
  if (!(await RNFS.exists(destDir))) {
    await RNFS.mkdir(destDir);
  }

  const items = await RNFS.readDir(srcDir);
  for (const item of items) {
    const dest = `${destDir}/${item.name}`;

    if (item.isDirectory()) {
      if ((await RNFS.exists(dest)) && (await RNFS.stat(dest)).isDirectory()) {
        await moveInto(item.path, dest, keepFiles);
      } else {
        if (await RNFS.exists(dest)) {
          await RNFS.unlink(dest);
        }
        await RNFS.moveFile(item.path, dest);
      }
      continue;
    }

    const exists = await RNFS.exists(dest);
    if (exists && keepFiles.includes(item.name)) {
      continue;
    }
    if (exists) {
      await RNFS.unlink(dest);
    }
    await RNFS.moveFile(item.path, dest);
  }
};

export const compareFileRecursion =
  ({ caches }: { caches: CacheType[] }): AppThunk =>
  async dispatch => {
    const { freeSpace } = await RNFS.getFSInfo();
    const zipBytes = caches[0]?.bytes?.[0] ?? GAME_ZIP_BYTES;
    const installed = await isGameInstalled();

    const isSuccessDownload = await AsyncStorage.getItem('isSuccessDownload');

    dispatch(
      setCompare({
        compare: {
          successCount: installed ? 1 : 0,
          rejectCount: installed ? 0 : 1,
          distributionCacheBytes: zipBytes,
          downloadsCacheBytes: installed ? zipBytes : 0,
          needDownloadsCacheBytes: installed ? 0 : zipBytes,
        },
        needDownload: installed ? [] : caches.slice(0, 1),
        freeSpace,
        isSuccessDownload:
          installed || isSuccessDownload === 'true' ? true : false,
      }),
    );
  };

export const fetchStartDownload = (): AppThunk => async (dispatch, state) => {
  const { needDownload } = state().loader;
  const filesContinue = state().distribution.filesContinue;
  const cache = needDownload[0];

  const baseDir = FilePath.getPathDirCache();
  const zipPath = `${baseDir}/${GAME_ZIP_NAME}`;
  const tempDir = `${baseDir}/.afro_extract`;

  const cleanup = async () => {
    try {
      if (await RNFS.exists(tempDir)) {
        await RNFS.unlink(tempDir);
      }
      if (await RNFS.exists(zipPath)) {
        await RNFS.unlink(zipPath);
      }
    } catch (e) {}
  };

  if (!cache) {
    dispatch(fetchIsDownloadSuccess());
    return navigationRef.current?.dispatch(StackActions.replace('Main'));
  }

  dispatch(createPushNotificationLoader());
  dispatch(
    onUploadTaskEventLoader({
      status: 'download',
      sizeFile: 0,
      currentFile: 1,
      size: 0,
      current: 1,
      file: '',
    }),
  );

  let totalBytes = cache.bytes[0] || GAME_ZIP_BYTES;

  try {
    await cleanup();
    await FilePath.createPathCache(baseDir, '');

    // 1) Download the single game files archive.
    dispatch(
      setDownloadLoader({
        download: {
          fileName: GAME_ZIP_NAME,
          currentBytes: 0,
          needBytes: totalBytes,
          numberOfDownloads: 0,
          downloadBytes: 0,
        },
      }),
    );

    const res = await RNFS.downloadFile({
      fromUrl: GAME_ZIP_URL,
      toFile: zipPath,
      progressInterval: 800,
      connectionTimeout: 30000,
      readTimeout: 60000,
      progress: ({ bytesWritten, contentLength }) => {
        if (contentLength > 0) {
          totalBytes = contentLength;
        }
        dispatch(
          setDownloadLoader({
            download: {
              currentBytes: bytesWritten,
              needBytes: totalBytes,
              downloadBytes: bytesWritten,
            },
          }),
        );
      },
    }).promise;

    if (res.statusCode !== 200) {
      throw new Error(`Download failed with status ${res.statusCode}`);
    }

    // 2) Extract it.
    dispatch(
      setDownloadLoader({
        download: {
          fileName: 'Extracting game files... (do not close the app)',
          currentBytes: 0,
          needBytes: totalBytes,
          downloadBytes: totalBytes,
        },
      }),
    );

    const subscription = subscribe(({ progress }) => {
      dispatch(
        setDownloadLoader({
          download: { currentBytes: Math.floor(progress * totalBytes) },
        }),
      );
    });

    try {
      await unzip(zipPath, tempDir);
    } finally {
      subscription.remove();
    }

    // 3) Find the real game folder (skip an extra wrapper folder if any).
    let root = tempDir;
    for (let i = 0; i < 3; i++) {
      const items = await RNFS.readDir(root);
      if (
        items.length === 1 &&
        items[0].isDirectory() &&
        !KNOWN_GAME_ITEMS.includes(items[0].name)
      ) {
        root = items[0].path;
      } else {
        break;
      }
    }

    // 4) Put the files in place, then remove the temporary files.
    await moveInto(root, baseDir, filesContinue);
    await cleanup();
    await RNFS.writeFile(markerPath(), GAME_FILES_VERSION, 'utf8');
  } catch (error) {
    await cleanup();
    dispatch(onUploadTaskEventLoader({ status: 'complete' }));
    return navigationRef.current?.dispatch(StackActions.replace('Error'));
  }

  dispatch(
    setDownloadLoader({
      download: { numberOfDownloads: 1, downloadBytes: totalBytes },
    }),
  );
  dispatch(setCacheReject(cache.id));
  dispatch(
    onUploadTaskEventLoader({
      status: 'download',
      sizeFile: 1,
      currentFile: 1,
      size: 1,
      current: 1,
      file: GAME_ZIP_NAME,
    }),
  );
  dispatch(onUploadTaskEventLoader({ status: 'complete' }));
  dispatch(fetchIsDownloadSuccess());
  return navigationRef.current?.dispatch(StackActions.replace('Main'));
};

// The winter map set is not used any more (only one game files archive).
export const nameFileRecursion = (): AppThunk => async () => false;

export const fetchIsDownloadSuccess = (): AppThunk => async dispatch => {
  try {
    await AsyncStorage.setItem('isSuccessDownload', 'true');
    dispatch(setSuccessDownload({ isSuccessDownload: true }));
  } catch (error) {
    dispatch(setSuccessDownload({ isSuccessDownload: false }));
  }
};
