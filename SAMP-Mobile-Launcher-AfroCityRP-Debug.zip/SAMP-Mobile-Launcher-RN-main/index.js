import './src/debug/errorHandler';
import React from 'react';
import { AppRegistry } from 'react-native';
import { Provider } from 'react-redux';
import { App } from './App';
import { name as appName } from './app.json';
import { ErrorBoundary } from './src/debug/ErrorBoundary';
import { store } from './src/store/store';

const RNRedux = () => (
  <ErrorBoundary>
    <Provider store={store}>
      <App />
    </Provider>
  </ErrorBoundary>
);

AppRegistry.registerComponent(appName, () => RNRedux);
